#include "style_dessin.h"

style_dessin::style_dessin()
{
    //ctor
}

style_dessin::~style_dessin()
{
    //dtor
}
