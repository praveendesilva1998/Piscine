#include "arrete.h"

#include <iostream>

Arrete::Arrete(int m_index1)
{
    this->m_index1 = m_index1;
}
Arrete::Arrete(double sommet1, double sommet2)
{
    int index1;
    m_index1 = index1;
	m_sommet1 = sommet1;
	m_sommet2 = sommet2;
}
