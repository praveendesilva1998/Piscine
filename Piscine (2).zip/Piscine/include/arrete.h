#ifndef ARRETE_H
#define ARRETE_H


class Arrete
{
	public:
	    int m_index, m_sommet1, m_sommet2, m_poids, m_weight;
	    //g�rer les poids sous forme de tableau [] ou de vector pour acceder aux diff�rents poids plus facilement
		Arrete(int index = 0);
		void arrete_set(int sommet1, int sommet2, int poids);

    private:


};

#endif
