#include "graphe.h"
#include "sommet.h"
#include "arrete.h"

using namespace std;

#include <iostream>
#include <vector>
#include <algorithm>
Graphe::Graphe(int sommet_count, int arrete_count)
{
	m_arrete_count = arrete_count;
	m_sommet_count = sommet_count;

	for (int a = 0, s = 0; s < sommet_count; a++, s++)
    {
		m_sommets.push_back(Sommet(s));
		m_arretes.push_back(Arrete(a));
	}
}

void Graphe::set_data(int index, int sommet1, int sommet2, int poids)
{
	m_arretes[index].arrete_set(sommet1, sommet2, poids);
	m_sommets[sommet1].m_adj.push_back(sommet2);
	m_sommets[sommet2].m_adj.push_back(sommet1);
}

void Graphe::display() const
{
	cout << "\nSommets: " << m_sommet_count << "\nArretes: " << m_arrete_count << endl << endl;
	for (int i = 0; i < m_sommet_count; i++)
        {
		cout << "Sommet " << m_sommets[i].m_index << " est adjacent aux sommets: ";
		for (int j = 0; j < m_sommets[i].m_adj.size(); j++)
			cout << m_sommets[i].m_adj[j] << ", ";
		cout << endl;
    	}

	cout << "\nLes Arretes :\n{ ";
	for (int i = 0; i < m_arrete_count; i++)
    {
        cout << "(" << m_arretes[i].m_sommet1 << ", " << m_arretes[i].m_sommet2 << "), ";
        cout << "}" << endl << endl;
    }


	for (int i = 0; i < m_arrete_count; i++)
    {
        cout << "Arrete " << i+1 << " est connecte aux sommets " << m_arretes[i].m_sommet1 << " et "
        << m_arretes[i].m_sommet2 << " avec un cout : " << m_arretes[i].m_poids << endl;
        cout << endl;
    }

}
class subset
{
    public:
    int sommet;
    int subsetID;
};

int find(struct subset subsets[], int i)
{
    // find root and make root as parent of i
    // (path compression)
    if (subsets[i].sommet != i)
        subsets[i].sommet = find(subsets, subsets[i].sommet);

    return subsets[i].sommet;
}


void Union(struct subset subsets[], int x, int y)
{
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);

    // Attach smaller rank tree under root of high
    // rank tree (Union by Rank)
    if (subsets[xroot].subsetID < subsets[yroot].subsetID)
        subsets[xroot].sommet = yroot;
    else if (subsets[xroot].subsetID > subsets[yroot].subsetID)
        subsets[yroot].sommet = xroot;

    // If ranks are same, then make one as root and
    // increment its rank by one
    else
    {
        subsets[yroot].sommet = xroot;
        subsets[xroot].subsetID++;
    }
}


bool comparaison (Arrete a, Arrete b)
{
    return a.m_poids < b.m_poids;
}


std::vector<Arrete> Graphe::executekruskal()
{

    int V = m_sommets.size();

    int e =0;
    int i = 0;
    std::vector <Arrete> result;
    std::vector <Arrete> allEdges;
    for(auto a : m_arretes)
    {
        allEdges.push_back(a);
    }

    //qsort(allEdges, allEdges.size(), sizeof(Arrete*), comparaison);
    std::sort(allEdges.begin(), allEdges.end(), comparaison);

    subset* subsets = (subset*) malloc( V * sizeof(subset) );

    // Create V subsets with single elements
    for (int v = 0; v < V; ++v)
    {
        subsets[v].sommet = v;
        subsets[v].subsetID = 0;
    }

    while (e < V - 1)
    {
        Arrete next_edge = allEdges[i++];
        int x = find(subsets, next_edge.m_sommet1);
        int y = find(subsets, next_edge.m_sommet2);
        if (x != y)
        {
            e++;
            result.push_back(next_edge);
            Union(subsets, x, y);
        }
    }

    // print the contents of result[] to display the
    // built MST
    printf("Following are the edges in the constructed MST\n");
    float poid =0;
    for(auto r : result)
    {

        printf("%d -- %d == %d\n", r.m_sommet1, r.m_sommet2, r.m_poids);
        poid += r.m_poids;
    }

    printf(" POID KRISKAL : %f",poid);

    return result;

}

